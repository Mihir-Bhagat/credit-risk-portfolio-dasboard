# Interview notes: be ready to explain every part

## 30-second pitch
A Streamlit dashboard over five bank tables (customers, loans, bureau, repayment history, collections). It cleans the data
with 14 documented decisions, profiles risk across income, employment, region, age and loan type, predicts default with a
logistic baseline and LightGBM, and embeds two AI features: *Ask the Portfolio* (an LLM turns a question into a JSON plan;
pandas computes the answer) and *anomaly detection* (peer-segment and own-history signals, with a human Confirm/Dismiss step).

## Decisions you must be able to defend
| Topic | What we did | Why |
|---|---|---|
| Observation point | End of repayment month 12; features use months 1-12 only | The data has no default date; the repayment file is exactly 12 months for every account |
| Collections data | Used for analytics, **not** as model input | Collection actions follow delinquency, so they would leak the outcome (and 3,875 events pre-date origination) |
| Bureau data | Used as supplied; a point-in-time version is a sensitivity run | Bureau lines have no as-of date and many open after every loan |
| Protected attributes | `gender`, `marital_status` not model inputs | Fairness; the tests confirm the exclusion |
| Split | By `customer_id` (80/20), tuning by GroupKFold on training only, test scored once | Customers own up to 3 accounts; otherwise leakage between train and test |
| Champion | Chosen by cross-validated AUC on training data, a rule written before the test was scored | Avoids picking the winner on the test set |
| Result | Logistic AUC 0.683 vs LightGBM 0.678; paired bootstrap says no reliable difference | Honest: the signal is modest (strongest single feature AUC 0.618, well under the 0.95 leakage ceiling) |
| Imputation | Medians within loan type for interest rate; flags kept; averages in Ask use observed values only | Imputed values must not pose as observations |
| Ask the Portfolio | LLM only returns a plan from a closed list; pandas runs it; text rendered locally; every number checked against the result | A model that never writes numbers cannot invent them |
| What is sent to the LLM | The question and the table catalog (descriptions, category names, limits). No rows, ids, results or keys | Privacy |
| Free-tier reality | Rate limits are real; the app falls back to the offline interpreter and says so | Demo must not break |

## Likely questions
- *Why is AUC only ~0.68?* Synthetic data with weak signals; the strongest single feature is income at 0.62. Repayment features add ~0.03, bureau ~0.005. Claiming more would mean leakage.
- *Why not pick LightGBM?* No reliable difference; the logistic model is simpler and easier to explain and was chosen by the pre-declared CV rule.
- *How would you monitor it?* PSI on score and top features, monthly AUC/KS/Gini on matured cohorts, calibration by risk band, data-quality checks, retrain triggers (see the Model tab and the PDF).
- *False positive of anomaly detection?* A one-off payment pause flagged as deterioration. *False negative?* Slow deterioration that never crosses the 99th percentile or the two-signal bar. Human Confirm/Dismiss never changes the model.
- *False positive of Ask?* A confidently wrong reading of "risky". *False negative?* A valid question declined, e.g. "more than 2 missed payments" is not supported.
- *What would production need from IT?* Dated default definition, bureau as-of dates, scheduled extracts with lineage, SSO, audit logs, an approved LLM gateway or on-prem model.

## Where things are
`src/ingestion.py` cleaning and join audit · `src/features.py` features and cutoffs · `src/analytics.py` insights · `src/model.py` models, SHAP, PSI · `src/anomaly.py` signals · `src/ask.py` guardrails, planner, execution, grounding · `src/decisions.py` decision store · `app/app.py` dashboard · `docs/` the two PDFs and the data-quality log · `tests/` the verification suite.
